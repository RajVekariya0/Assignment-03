function getTeamData() {
  $.getJSON('team.json', function(data) {
    $.each(data, function(index, element) {
      var name = element.name;
      var position = element.position;
      var bio = element.bio;
      
      var html = '<div>' +
                   '<h2>' + name + '</h2>' +
                   '<h5>' + position + '</h5>' +
                   '<p>' + bio + '</p>' +
                 '</div>';
      
      $('#team').append(html);
    });
    console.log("Data retrieved successfully:", data);
  })
  .fail(function() {
    $('#team').text("Error: Content could not be retrieved.");
    console.error("An error occurred while retrieving the data.");
  });
}

function getAjaxData(url, beforeSendCallback, successCallback, errorCallback) {
  $.ajax({
    url: url,
    type: "GET",
    beforeSend: function() {
      if (beforeSendCallback) {
        beforeSendCallback();
      }
    }
  })
  .done(function(data) {
    // Add a 3-second delay before appending the data to the page
    setTimeout(function() {
      if (successCallback) {
        successCallback(data);
      }
    }, 3000);
  })
  .fail(function(jqxhr, textStatus, error) {
    if (errorCallback) {
      errorCallback(textStatus + ": " + error);
    }
  });
}

getTeamData();

getAjaxData(
  "team.json",
  function() {
    $('#team').text("Loading...");
  },
  function(data) {
    $('#team').empty(); // clear the loading text
    $.each(data, function(index, element) {
      var name = element.name;
      var position = element.position;
      var bio = element.bio;
      
      var html = '<div>' +
                   '<h2>' + name + '</h2>' +
                   '<h5>' + position + '</h5>' +
                   '<p>' + bio + '</p>' +
                 '</div>';
      
      $('#team').append(html);
    });
    console.log("Data retrieved successfully:", data);
  },
  function(error) {
    $('#team').text("Error: Content could not be retrieved.");
    console.error("An error occurred:", error);
  }
);
